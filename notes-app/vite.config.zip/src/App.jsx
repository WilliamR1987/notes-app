import "./index.css"

const App = () => {
  return (
  <div class = 'max-w-lg mx-auto mt-10 p-6 bg-gray-100 rounded-lg'>
    My App
  </div>)

}

export default App